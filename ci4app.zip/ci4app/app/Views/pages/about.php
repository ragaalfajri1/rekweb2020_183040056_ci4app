<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>
<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nulla reiciendis vitae dolorum cum ad tempore impedit delectus minima, provident similique. Et aliquid, rerum qui praesentium laborum deleniti iure? Natus, placeat!</p>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>